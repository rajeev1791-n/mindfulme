# MindfulME Deployment Guide

## Overview

This guide covers deploying the MindfulME application to production environments, including both backend and frontend components.

## Prerequisites

### System Requirements
- **Operating System**: Ubuntu 20.04+ or similar Linux distribution
- **Memory**: Minimum 2GB RAM, recommended 4GB+
- **Storage**: Minimum 20GB available space
- **Network**: Stable internet connection with public IP access

### Software Dependencies
- **Docker**: Version 20.10+
- **Docker Compose**: Version 2.0+
- **Node.js**: Version 18+ (for build process)
- **Python**: Version 3.11+ (for backend)
- **PostgreSQL**: Version 13+ (production database)
- **Nginx**: Version 1.18+ (reverse proxy)

## Environment Setup

### 1. Server Preparation

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Install Nginx
sudo apt install nginx -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 2. SSL Certificate Setup

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx -y

# Obtain SSL certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

## Database Setup

### PostgreSQL Installation and Configuration

```bash
# Install PostgreSQL
sudo apt install postgresql postgresql-contrib -y

# Start and enable PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql << EOF
CREATE DATABASE mindfulme_prod;
CREATE USER mindfulme_user WITH PASSWORD 'secure_password_here';
GRANT ALL PRIVILEGES ON DATABASE mindfulme_prod TO mindfulme_user;
ALTER USER mindfulme_user CREATEDB;
\q
EOF
```

### Database Configuration

Create `/etc/postgresql/13/main/postgresql.conf` modifications:
```conf
# Connection settings
listen_addresses = 'localhost'
port = 5432

# Memory settings
shared_buffers = 256MB
effective_cache_size = 1GB
work_mem = 4MB

# Logging
log_statement = 'all'
log_duration = on
log_line_prefix = '%t [%p]: [%l-1] user=%u,db=%d,app=%a,client=%h '
```

## Backend Deployment

### 1. Application Setup

```bash
# Create application directory
sudo mkdir -p /opt/mindfulme
sudo chown $USER:$USER /opt/mindfulme
cd /opt/mindfulme

# Clone repository (or copy files)
git clone https://github.com/your-org/mindfulme-app.git .
# OR: Copy your application files here

# Set up Python environment
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 2. Environment Configuration

Create `/opt/mindfulme/backend/.env`:
```env
# Flask Configuration
FLASK_ENV=production
SECRET_KEY=your_super_secret_key_here_change_this
DEBUG=False

# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=mindfulme_prod
DB_USERNAME=mindfulme_user
DB_PASSWORD=secure_password_here

# JWT Configuration
JWT_SECRET_KEY=another_secret_key_for_jwt_tokens

# Email Configuration (for notifications)
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password

# External API Keys
SOCIAL_MEDIA_API_KEY=your_api_key_here
ANALYTICS_API_KEY=your_analytics_key_here

# Security Settings
CORS_ORIGINS=https://yourdomain.com,https://www.yourdomain.com
```

### 3. Docker Configuration

Create `/opt/mindfulme/backend/Dockerfile`:
```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements and install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Create non-root user
RUN useradd --create-home --shell /bin/bash app
RUN chown -R app:app /app
USER app

# Expose port
EXPOSE 5000

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:5000/health || exit 1

# Start application
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "--workers", "4", "--timeout", "120", "src.main:app"]
```

### 4. Gunicorn Configuration

Create `/opt/mindfulme/backend/gunicorn.conf.py`:
```python
import multiprocessing

# Server socket
bind = "0.0.0.0:5000"
backlog = 2048

# Worker processes
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"
worker_connections = 1000
timeout = 120
keepalive = 2

# Restart workers
max_requests = 1000
max_requests_jitter = 50
preload_app = True

# Logging
accesslog = "/var/log/mindfulme/access.log"
errorlog = "/var/log/mindfulme/error.log"
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'

# Process naming
proc_name = "mindfulme_backend"

# Server mechanics
daemon = False
pidfile = "/var/run/mindfulme/backend.pid"
user = "app"
group = "app"
tmp_upload_dir = None

# SSL (if terminating SSL at application level)
# keyfile = "/path/to/keyfile"
# certfile = "/path/to/certfile"
```

## Frontend Deployment

### 1. Build Process

```bash
cd /opt/mindfulme/frontend

# Install dependencies
npm install

# Build for production
npm run build

# The built files will be in the 'dist' directory
```

### 2. Nginx Configuration

Create `/etc/nginx/sites-available/mindfulme`:
```nginx
# Rate limiting
limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
limit_req_zone $binary_remote_addr zone=login:10m rate=5r/m;

# Upstream backend servers
upstream backend {
    server 127.0.0.1:5000;
    # Add more servers for load balancing
    # server 127.0.0.1:5001;
}

# HTTP redirect to HTTPS
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

# HTTPS server
server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    # SSL configuration
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self' https://api.yourdomain.com;";

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/json
        application/javascript
        application/xml+rss
        application/atom+xml
        image/svg+xml;

    # Root directory for frontend files
    root /opt/mindfulme/frontend/dist;
    index index.html;

    # Frontend routes (SPA)
    location / {
        try_files $uri $uri/ /index.html;
        
        # Cache static assets
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }

    # API routes
    location /api/ {
        # Rate limiting
        limit_req zone=api burst=20 nodelay;
        
        # Special rate limiting for auth endpoints
        location /api/auth/login {
            limit_req zone=login burst=5 nodelay;
            proxy_pass http://backend;
            include /etc/nginx/proxy_params;
        }
        
        proxy_pass http://backend;
        include /etc/nginx/proxy_params;
        
        # CORS headers (if not handled by backend)
        add_header Access-Control-Allow-Origin "https://yourdomain.com" always;
        add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS" always;
        add_header Access-Control-Allow-Headers "Authorization, Content-Type" always;
        
        # Handle preflight requests
        if ($request_method = 'OPTIONS') {
            add_header Access-Control-Allow-Origin "https://yourdomain.com";
            add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS";
            add_header Access-Control-Allow-Headers "Authorization, Content-Type";
            add_header Access-Control-Max-Age 1728000;
            add_header Content-Type "text/plain charset=UTF-8";
            add_header Content-Length 0;
            return 204;
        }
    }

    # Health check endpoint
    location /health {
        proxy_pass http://backend;
        access_log off;
    }

    # Deny access to sensitive files
    location ~ /\. {
        deny all;
    }
    
    location ~ /(\.env|\.git|\.htaccess|\.htpasswd) {
        deny all;
    }
}
```

Create `/etc/nginx/proxy_params`:
```nginx
proxy_set_header Host $http_host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $scheme;
proxy_set_header X-Forwarded-Host $server_name;
proxy_redirect off;
proxy_buffering off;
proxy_connect_timeout 60s;
proxy_send_timeout 60s;
proxy_read_timeout 60s;
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/mindfulme /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## Docker Compose Deployment

Create `/opt/mindfulme/docker-compose.prod.yml`:
```yaml
version: '3.8'

services:
  backend:
    build: 
      context: ./backend
      dockerfile: Dockerfile
    container_name: mindfulme_backend
    restart: unless-stopped
    environment:
      - FLASK_ENV=production
    env_file:
      - ./backend/.env
    ports:
      - "127.0.0.1:5000:5000"
    volumes:
      - ./logs:/var/log/mindfulme
      - ./uploads:/app/uploads
    depends_on:
      - redis
    networks:
      - mindfulme_network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:5000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  redis:
    image: redis:7-alpine
    container_name: mindfulme_redis
    restart: unless-stopped
    ports:
      - "127.0.0.1:6379:6379"
    volumes:
      - redis_data:/data
    networks:
      - mindfulme_network
    command: redis-server --appendonly yes

  nginx:
    image: nginx:alpine
    container_name: mindfulme_nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./frontend/dist:/usr/share/nginx/html
      - ./nginx.conf:/etc/nginx/nginx.conf
      - /etc/letsencrypt:/etc/letsencrypt
    depends_on:
      - backend
    networks:
      - mindfulme_network

volumes:
  redis_data:

networks:
  mindfulme_network:
    driver: bridge
```

## Monitoring and Logging

### 1. Log Management

```bash
# Create log directories
sudo mkdir -p /var/log/mindfulme
sudo chown app:app /var/log/mindfulme

# Configure log rotation
sudo tee /etc/logrotate.d/mindfulme << EOF
/var/log/mindfulme/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 app app
    postrotate
        systemctl reload nginx
    endscript
}
EOF
```

### 2. System Monitoring

Install monitoring tools:
```bash
# Install monitoring stack
sudo apt install prometheus node-exporter grafana -y

# Configure Prometheus
sudo tee /etc/prometheus/prometheus.yml << EOF
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'node'
    static_configs:
      - targets: ['localhost:9100']
  
  - job_name: 'mindfulme-backend'
    static_configs:
      - targets: ['localhost:5000']
    metrics_path: '/metrics'
EOF

# Start services
sudo systemctl enable prometheus grafana-server node-exporter
sudo systemctl start prometheus grafana-server node-exporter
```

### 3. Application Health Checks

Add health check endpoint to Flask app:
```python
@app.route('/health')
def health_check():
    try:
        # Check database connection
        db.session.execute('SELECT 1')
        
        # Check Redis connection
        redis_client.ping()
        
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.utcnow().isoformat(),
            'version': '1.0.0'
        }), 200
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 503
```

## Security Hardening

### 1. Firewall Configuration

```bash
# Configure UFW firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

### 2. Fail2Ban Setup

```bash
# Install Fail2Ban
sudo apt install fail2ban -y

# Configure Fail2Ban for Nginx
sudo tee /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 5

[nginx-http-auth]
enabled = true

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
action = iptables-multiport[name=ReqLimit, port="http,https", protocol=tcp]
logpath = /var/log/nginx/error.log
findtime = 600
bantime = 7200
maxretry = 10
EOF

sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 3. Database Security

```bash
# Secure PostgreSQL installation
sudo -u postgres psql << EOF
-- Remove default postgres user password
ALTER USER postgres PASSWORD 'secure_postgres_password';

-- Create read-only user for monitoring
CREATE USER monitoring WITH PASSWORD 'monitoring_password';
GRANT CONNECT ON DATABASE mindfulme_prod TO monitoring;
GRANT USAGE ON SCHEMA public TO monitoring;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO monitoring;
EOF

# Configure PostgreSQL security
sudo tee -a /etc/postgresql/13/main/pg_hba.conf << EOF
# Application connections
host    mindfulme_prod    mindfulme_user    127.0.0.1/32    md5
host    mindfulme_prod    monitoring        127.0.0.1/32    md5
EOF

sudo systemctl restart postgresql
```

## Backup and Recovery

### 1. Database Backups

Create backup script `/opt/mindfulme/scripts/backup.sh`:
```bash
#!/bin/bash

BACKUP_DIR="/opt/mindfulme/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_NAME="mindfulme_prod"
DB_USER="mindfulme_user"

# Create backup directory
mkdir -p $BACKUP_DIR

# Database backup
pg_dump -h localhost -U $DB_USER -d $DB_NAME | gzip > $BACKUP_DIR/db_backup_$DATE.sql.gz

# Application files backup
tar -czf $BACKUP_DIR/app_backup_$DATE.tar.gz /opt/mindfulme --exclude=/opt/mindfulme/backups

# Clean old backups (keep 30 days)
find $BACKUP_DIR -name "*.gz" -mtime +30 -delete

echo "Backup completed: $DATE"
```

### 2. Automated Backups

```bash
# Make script executable
chmod +x /opt/mindfulme/scripts/backup.sh

# Add to crontab for daily backups
(crontab -l 2>/dev/null; echo "0 2 * * * /opt/mindfulme/scripts/backup.sh") | crontab -
```

## Deployment Process

### 1. Initial Deployment

```bash
# Deploy application
cd /opt/mindfulme
docker-compose -f docker-compose.prod.yml up -d

# Initialize database
docker-compose exec backend python -c "
from src.main import app, db
with app.app_context():
    db.create_all()
    print('Database initialized')
"

# Verify deployment
curl -f https://yourdomain.com/health
```

### 2. Updates and Rollbacks

Create deployment script `/opt/mindfulme/scripts/deploy.sh`:
```bash
#!/bin/bash

set -e

echo "Starting deployment..."

# Pull latest code
git pull origin main

# Build new images
docker-compose -f docker-compose.prod.yml build

# Run database migrations
docker-compose -f docker-compose.prod.yml run --rm backend python -c "
from src.main import app, db
from flask_migrate import upgrade
with app.app_context():
    upgrade()
"

# Deploy with zero downtime
docker-compose -f docker-compose.prod.yml up -d

# Health check
sleep 10
if curl -f https://yourdomain.com/health; then
    echo "Deployment successful!"
else
    echo "Deployment failed, rolling back..."
    docker-compose -f docker-compose.prod.yml rollback
    exit 1
fi
```

## Performance Optimization

### 1. Database Optimization

```sql
-- Create indexes for better performance
CREATE INDEX idx_students_user_id ON students(user_id);
CREATE INDEX idx_usage_sessions_student_id ON usage_sessions(student_id);
CREATE INDEX idx_usage_sessions_date ON usage_sessions(start_time);
CREATE INDEX idx_point_transactions_student_id ON point_transactions(student_id);
CREATE INDEX idx_friendships_user_ids ON friendships(user1_id, user2_id);

-- Analyze tables for query optimization
ANALYZE;
```

### 2. Redis Caching

Configure Redis for session storage and caching:
```python
# Add to Flask configuration
REDIS_URL = 'redis://localhost:6379/0'
SESSION_TYPE = 'redis'
SESSION_REDIS = redis.from_url(REDIS_URL)
CACHE_TYPE = 'redis'
CACHE_REDIS_URL = REDIS_URL
```

### 3. CDN Setup

Configure CloudFlare or similar CDN:
- Enable caching for static assets
- Set up image optimization
- Configure security rules
- Enable DDoS protection

## Troubleshooting

### Common Issues

1. **Database Connection Errors**
   ```bash
   # Check PostgreSQL status
   sudo systemctl status postgresql
   
   # Check logs
   sudo tail -f /var/log/postgresql/postgresql-13-main.log
   ```

2. **High Memory Usage**
   ```bash
   # Monitor memory usage
   free -h
   docker stats
   
   # Restart services if needed
   docker-compose restart
   ```

3. **SSL Certificate Issues**
   ```bash
   # Renew certificates
   sudo certbot renew
   
   # Test certificate
   sudo certbot certificates
   ```

### Monitoring Commands

```bash
# Check application status
docker-compose ps

# View logs
docker-compose logs -f backend

# Monitor system resources
htop
iotop
nethogs

# Check Nginx status
sudo nginx -t
sudo systemctl status nginx
```

This deployment guide provides a comprehensive setup for production deployment of the MindfulME application with security, monitoring, and backup considerations.


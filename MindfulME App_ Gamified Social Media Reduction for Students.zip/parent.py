from flask import Blueprint, jsonify, request
from src.models.user import Parent, Student, UsageSession, db
from src.routes.auth import token_required
from datetime import datetime, timedelta
from sqlalchemy import func

parent_bp = Blueprint('parent', __name__)

@parent_bp.route('/children', methods=['GET'])
@token_required
def get_children(current_user):
    try:
        if current_user.user_type != 'parent':
            return jsonify({'message': 'Access denied'}), 403
        
        parent = Parent.query.filter_by(user_id=current_user.id).first()
        if not parent:
            return jsonify({'message': 'Parent profile not found'}), 404
        
        children = Student.query.filter_by(parent_id=parent.id).all()
        
        return jsonify({
            'children': [child.to_dict() for child in children]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get children: {str(e)}'}), 500

@parent_bp.route('/link-child', methods=['POST'])
@token_required
def link_child(current_user):
    try:
        if current_user.user_type != 'parent':
            return jsonify({'message': 'Access denied'}), 403
        
        parent = Parent.query.filter_by(user_id=current_user.id).first()
        if not parent:
            return jsonify({'message': 'Parent profile not found'}), 404
        
        data = request.json
        if 'child_email' not in data:
            return jsonify({'message': 'child_email is required'}), 400
        
        # Find student by email
        from src.models.user import User
        child_user = User.query.filter_by(email=data['child_email'], user_type='student').first()
        if not child_user:
            return jsonify({'message': 'Student not found with this email'}), 404
        
        child = Student.query.filter_by(user_id=child_user.id).first()
        if not child:
            return jsonify({'message': 'Student profile not found'}), 404
        
        if child.parent_id:
            return jsonify({'message': 'Student is already linked to a parent'}), 400
        
        # Link child to parent
        child.parent_id = parent.id
        db.session.commit()
        
        return jsonify({
            'message': 'Child linked successfully',
            'child': child.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to link child: {str(e)}'}), 500

@parent_bp.route('/reports/<int:child_id>', methods=['GET'])
@token_required
def get_child_report(current_user, child_id):
    try:
        if current_user.user_type != 'parent':
            return jsonify({'message': 'Access denied'}), 403
        
        parent = Parent.query.filter_by(user_id=current_user.id).first()
        if not parent:
            return jsonify({'message': 'Parent profile not found'}), 404
        
        # Verify child belongs to this parent
        child = Student.query.filter_by(id=child_id, parent_id=parent.id).first()
        if not child:
            return jsonify({'message': 'Child not found or not linked to this parent'}), 404
        
        # Get date range from query params
        days = request.args.get('days', 7, type=int)
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Get usage statistics
        usage_stats = db.session.query(
            func.date(UsageSession.start_time).label('date'),
            func.sum(UsageSession.duration_minutes).label('total_minutes'),
            func.count(UsageSession.id).label('session_count')
        ).filter(
            UsageSession.student_id == child.id,
            UsageSession.start_time >= start_date
        ).group_by(func.date(UsageSession.start_time)).all()
        
        # Get platform breakdown
        platform_stats = db.session.query(
            UsageSession.platform,
            func.sum(UsageSession.duration_minutes).label('total_minutes'),
            func.avg(UsageSession.duration_minutes).label('avg_minutes')
        ).filter(
            UsageSession.student_id == child.id,
            UsageSession.start_time >= start_date
        ).group_by(UsageSession.platform).all()
        
        # Calculate total usage
        total_usage = db.session.query(
            func.sum(UsageSession.duration_minutes)
        ).filter(
            UsageSession.student_id == child.id,
            UsageSession.start_time >= start_date
        ).scalar() or 0
        
        return jsonify({
            'child': child.to_dict(),
            'report_period_days': days,
            'total_usage_minutes': total_usage,
            'daily_stats': [
                {
                    'date': stat.date.isoformat(),
                    'total_minutes': stat.total_minutes,
                    'session_count': stat.session_count
                } for stat in usage_stats
            ],
            'platform_stats': [
                {
                    'platform': stat.platform,
                    'total_minutes': stat.total_minutes,
                    'avg_minutes': float(stat.avg_minutes)
                } for stat in platform_stats
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get child report: {str(e)}'}), 500

@parent_bp.route('/settings/<int:child_id>', methods=['PUT'])
@token_required
def update_child_settings(current_user, child_id):
    try:
        if current_user.user_type != 'parent':
            return jsonify({'message': 'Access denied'}), 403
        
        parent = Parent.query.filter_by(user_id=current_user.id).first()
        if not parent:
            return jsonify({'message': 'Parent profile not found'}), 404
        
        # Verify child belongs to this parent
        child = Student.query.filter_by(id=child_id, parent_id=parent.id).first()
        if not child:
            return jsonify({'message': 'Child not found or not linked to this parent'}), 404
        
        data = request.json
        
        # For now, we'll just return success
        # In a real app, you might want to store settings in a separate table
        
        return jsonify({
            'message': 'Child settings updated successfully',
            'settings': data
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to update child settings: {str(e)}'}), 500

@parent_bp.route('/subscription', methods=['GET'])
@token_required
def get_subscription(current_user):
    try:
        if current_user.user_type != 'parent':
            return jsonify({'message': 'Access denied'}), 403
        
        parent = Parent.query.filter_by(user_id=current_user.id).first()
        if not parent:
            return jsonify({'message': 'Parent profile not found'}), 404
        
        return jsonify({
            'subscription_status': parent.subscription_status,
            'subscription_expires': parent.subscription_expires.isoformat() if parent.subscription_expires else None
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get subscription: {str(e)}'}), 500

@parent_bp.route('/subscription', methods=['PUT'])
@token_required
def update_subscription(current_user):
    try:
        if current_user.user_type != 'parent':
            return jsonify({'message': 'Access denied'}), 403
        
        parent = Parent.query.filter_by(user_id=current_user.id).first()
        if not parent:
            return jsonify({'message': 'Parent profile not found'}), 404
        
        data = request.json
        
        if 'subscription_status' in data:
            parent.subscription_status = data['subscription_status']
        
        if 'subscription_expires' in data:
            parent.subscription_expires = datetime.fromisoformat(data['subscription_expires'].replace('Z', '+00:00'))
        
        db.session.commit()
        
        return jsonify({
            'message': 'Subscription updated successfully',
            'subscription_status': parent.subscription_status,
            'subscription_expires': parent.subscription_expires.isoformat() if parent.subscription_expires else None
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to update subscription: {str(e)}'}), 500


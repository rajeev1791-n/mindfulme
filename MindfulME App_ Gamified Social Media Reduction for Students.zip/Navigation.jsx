import { Link, useLocation } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { useAuth } from '../App'
import { Home, Award, BookOpen, Users, LogOut } from 'lucide-react'

export default function Navigation() {
  const { user, logout } = useAuth()
  const location = useLocation()

  const studentNavItems = [
    { path: '/student', icon: Home, label: 'Dashboard' },
    { path: '/rewards', icon: Award, label: 'Rewards' },
    { path: '/learning', icon: BookOpen, label: 'Learning' },
    { path: '/social', icon: Users, label: 'Social' }
  ]

  const parentNavItems = [
    { path: '/parent', icon: Home, label: 'Dashboard' },
    { path: '/learning', icon: BookOpen, label: 'Learning' }
  ]

  const navItems = user?.user_type === 'student' ? studentNavItems : parentNavItems

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <img src="/src/assets/logo.png" alt="MindfulME" className="w-8 h-8 mr-3" />
            <span className="text-xl font-bold text-gray-800">MindfulME</span>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = location.pathname === item.path
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? 'text-blue-600 bg-blue-50'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </Link>
              )
            })}
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              {user?.user_type === 'student' ? 'Student' : 'Parent'}
            </span>
            <Button
              onClick={logout}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </Button>
          </div>
        </div>

        {/* Mobile navigation */}
        <div className="md:hidden">
          <div className="flex justify-around py-2 border-t border-gray-200">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = location.pathname === item.path
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-md text-xs font-medium transition-colors ${
                    isActive
                      ? 'text-blue-600'
                      : 'text-gray-600'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </Link>
              )
            })}
          </div>
        </div>
      </div>
    </nav>
  )
}


import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.routes.auth import auth_bp
from src.routes.student import student_bp
from src.routes.parent import parent_bp
from src.routes.rewards import rewards_bp
from src.routes.social import social_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# Enable CORS for all routes
CORS(app)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(student_bp, url_prefix='/api/students')
app.register_blueprint(parent_bp, url_prefix='/api/parents')
app.register_blueprint(rewards_bp, url_prefix='/api/rewards')
app.register_blueprint(social_bp, url_prefix='/api/social')

# Enable database
app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('DB_USERNAME', 'root')}:{os.getenv('DB_PASSWORD', 'password')}@{os.getenv('DB_HOST', 'localhost')}:{os.getenv('DB_PORT', '3306')}/{os.getenv('DB_NAME', 'mydb')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
            return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

# Initialize database tables
with app.app_context():
    db.create_all()
    
    # Create sample data
    from src.models.user import Reward, Achievement
    
    # Create sample rewards if they don't exist
    if not Reward.query.first():
        sample_rewards = [
            Reward(title="Starbucks $5 Gift Card", description="Enjoy your favorite coffee", points_cost=500, category="Food", merchant_name="Starbucks", discount_percentage=None),
            Reward(title="20% off Nike Shoes", description="Get 20% off on any Nike footwear", points_cost=800, category="Shopping", merchant_name="Nike", discount_percentage=20),
            Reward(title="Movie Theater Ticket", description="Free movie ticket at AMC theaters", points_cost=1200, category="Entertainment", merchant_name="AMC", discount_percentage=None),
            Reward(title="Coursera Course Access", description="1-month access to any Coursera course", points_cost=1000, category="Education", merchant_name="Coursera", discount_percentage=None),
            Reward(title="Spotify Premium (1 month)", description="One month of Spotify Premium", points_cost=600, category="Entertainment", merchant_name="Spotify", discount_percentage=None)
        ]
        
        for reward in sample_rewards:
            db.session.add(reward)
    
    # Create sample achievements if they don't exist
    if not Achievement.query.first():
        sample_achievements = [
            Achievement(name="First Steps", description="Complete your first day of reduced usage", badge_icon="🎯", points_reward=50),
            Achievement(name="Week Warrior", description="Maintain reduced usage for 7 consecutive days", badge_icon="🏆", points_reward=200),
            Achievement(name="Social Butterfly", description="Add your first friend", badge_icon="🦋", points_reward=100),
            Achievement(name="Point Collector", description="Earn your first 1000 points", badge_icon="💎", points_reward=100),
            Achievement(name="Level Up", description="Reach level 5", badge_icon="⭐", points_reward=300)
        ]
        
        for achievement in sample_achievements:
            db.session.add(achievement)
    
    db.session.commit()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)


from flask import Blueprint, jsonify, request
from src.models.user import Student, Friendship, StudentAchievement, Achievement, db
from src.routes.auth import token_required
from sqlalchemy import or_, and_

social_bp = Blueprint('social', __name__)

@social_bp.route('/leaderboard', methods=['GET'])
@token_required
def get_leaderboard(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Only students can view leaderboard'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        # Get friends of current student
        friendships = Friendship.query.filter(
            or_(
                and_(Friendship.student1_id == student.id, Friendship.status == 'accepted'),
                and_(Friendship.student2_id == student.id, Friendship.status == 'accepted')
            )
        ).all()
        
        friend_ids = []
        for friendship in friendships:
            if friendship.student1_id == student.id:
                friend_ids.append(friendship.student2_id)
            else:
                friend_ids.append(friendship.student1_id)
        
        # Include current student in leaderboard
        friend_ids.append(student.id)
        
        # Get leaderboard data
        leaderboard = Student.query.filter(
            Student.id.in_(friend_ids)
        ).order_by(Student.points_balance.desc()).all()
        
        return jsonify({
            'leaderboard': [
                {
                    'student_id': s.id,
                    'name': f"{s.first_name} {s.last_name}",
                    'points': s.points_balance,
                    'level': s.level,
                    'streak_days': s.streak_days,
                    'is_current_user': s.id == student.id
                } for s in leaderboard
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get leaderboard: {str(e)}'}), 500

@social_bp.route('/friends', methods=['GET'])
@token_required
def get_friends(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Only students can view friends'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        # Get all friendships involving this student
        friendships = Friendship.query.filter(
            or_(Friendship.student1_id == student.id, Friendship.student2_id == student.id)
        ).all()
        
        friends_data = []
        for friendship in friendships:
            friend_id = friendship.student2_id if friendship.student1_id == student.id else friendship.student1_id
            friend = Student.query.get(friend_id)
            
            if friend:
                friends_data.append({
                    'friendship_id': friendship.id,
                    'friend': {
                        'id': friend.id,
                        'name': f"{friend.first_name} {friend.last_name}",
                        'points': friend.points_balance,
                        'level': friend.level
                    },
                    'status': friendship.status,
                    'created_at': friendship.created_at.isoformat()
                })
        
        return jsonify({
            'friends': friends_data
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get friends: {str(e)}'}), 500

@social_bp.route('/add-friend', methods=['POST'])
@token_required
def add_friend(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Only students can add friends'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        data = request.json
        if 'friend_email' not in data:
            return jsonify({'message': 'friend_email is required'}), 400
        
        # Find friend by email
        from src.models.user import User
        friend_user = User.query.filter_by(email=data['friend_email'], user_type='student').first()
        if not friend_user:
            return jsonify({'message': 'Student not found with this email'}), 404
        
        friend = Student.query.filter_by(user_id=friend_user.id).first()
        if not friend:
            return jsonify({'message': 'Student profile not found'}), 404
        
        if friend.id == student.id:
            return jsonify({'message': 'Cannot add yourself as friend'}), 400
        
        # Check if friendship already exists
        existing_friendship = Friendship.query.filter(
            or_(
                and_(Friendship.student1_id == student.id, Friendship.student2_id == friend.id),
                and_(Friendship.student1_id == friend.id, Friendship.student2_id == student.id)
            )
        ).first()
        
        if existing_friendship:
            return jsonify({'message': 'Friendship already exists'}), 400
        
        # Create friendship request
        friendship = Friendship(
            student1_id=student.id,
            student2_id=friend.id,
            status='pending'
        )
        
        db.session.add(friendship)
        db.session.commit()
        
        return jsonify({
            'message': 'Friend request sent successfully',
            'friendship': friendship.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to add friend: {str(e)}'}), 500

@social_bp.route('/friend-requests', methods=['GET'])
@token_required
def get_friend_requests(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Only students can view friend requests'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        # Get pending friend requests where this student is the recipient
        requests = Friendship.query.filter_by(
            student2_id=student.id,
            status='pending'
        ).all()
        
        requests_data = []
        for request in requests:
            requester = Student.query.get(request.student1_id)
            if requester:
                requests_data.append({
                    'friendship_id': request.id,
                    'requester': {
                        'id': requester.id,
                        'name': f"{requester.first_name} {requester.last_name}",
                        'points': requester.points_balance,
                        'level': requester.level
                    },
                    'created_at': request.created_at.isoformat()
                })
        
        return jsonify({
            'friend_requests': requests_data
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get friend requests: {str(e)}'}), 500

@social_bp.route('/friend-requests/<int:friendship_id>/respond', methods=['PUT'])
@token_required
def respond_to_friend_request(current_user, friendship_id):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Only students can respond to friend requests'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        data = request.json
        if 'action' not in data or data['action'] not in ['accept', 'reject']:
            return jsonify({'message': 'action must be "accept" or "reject"'}), 400
        
        friendship = Friendship.query.filter_by(
            id=friendship_id,
            student2_id=student.id,
            status='pending'
        ).first()
        
        if not friendship:
            return jsonify({'message': 'Friend request not found'}), 404
        
        if data['action'] == 'accept':
            friendship.status = 'accepted'
        else:
            friendship.status = 'rejected'
        
        db.session.commit()
        
        return jsonify({
            'message': f'Friend request {data["action"]}ed successfully',
            'friendship': friendship.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to respond to friend request: {str(e)}'}), 500

@social_bp.route('/achievements', methods=['GET'])
@token_required
def get_achievements(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Only students can view achievements'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        # Get student's achievements
        student_achievements = StudentAchievement.query.filter_by(
            student_id=student.id
        ).all()
        
        # Get all available achievements
        all_achievements = Achievement.query.all()
        
        earned_achievement_ids = [sa.achievement_id for sa in student_achievements]
        
        achievements_data = []
        for achievement in all_achievements:
            achievements_data.append({
                'achievement': achievement.to_dict(),
                'earned': achievement.id in earned_achievement_ids,
                'earned_at': next(
                    (sa.earned_at.isoformat() for sa in student_achievements if sa.achievement_id == achievement.id),
                    None
                )
            })
        
        return jsonify({
            'achievements': achievements_data,
            'total_earned': len(earned_achievement_ids)
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get achievements: {str(e)}'}), 500


# MindfulME API Documentation

## Base URL
```
http://localhost:5001/api
```

## Authentication

All protected endpoints require a JWT token in the Authorization header:
```
Authorization: Bearer <token>
```

## Authentication Endpoints

### POST /auth/register
Register a new user account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "user_type": "student", // or "parent"
  "first_name": "John",
  "last_name": "Doe",
  "age": 19 // required for students only
}
```

**Response:**
```json
{
  "message": "User registered successfully",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "user_type": "student"
  },
  "profile": {
    "first_name": "John",
    "last_name": "Doe",
    "points_balance": 0,
    "level": 1
  },
  "token": "jwt_token_here"
}
```

### POST /auth/login
Authenticate user and get access token.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "message": "Login successful",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "user_type": "student"
  },
  "profile": {
    "first_name": "John",
    "last_name": "Doe",
    "points_balance": 1250,
    "level": 3
  },
  "token": "jwt_token_here"
}
```

### GET /auth/profile
Get current user profile information.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "user": {
    "id": 1,
    "email": "user@example.com",
    "user_type": "student"
  },
  "profile": {
    "first_name": "John",
    "last_name": "Doe",
    "points_balance": 1250,
    "level": 3,
    "streak_days": 7
  }
}
```

## Student Endpoints

### GET /students/dashboard
Get student dashboard data including stats and recent activity.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "today_usage_minutes": 45,
  "daily_goal_minutes": 120,
  "daily_goal_progress": 62.5,
  "usage_stats": [
    {
      "date": "2025-06-08",
      "total_minutes": 45,
      "session_count": 3
    }
  ],
  "recent_transactions": [
    {
      "id": 1,
      "points": 50,
      "description": "Daily goal achieved",
      "transaction_type": "earned",
      "created_at": "2025-06-08T10:00:00Z"
    }
  ]
}
```

### POST /students/usage/session
Log a social media usage session.

**Headers:**
```
Authorization: Bearer <token>
```

**Request Body:**
```json
{
  "platform": "Instagram",
  "start_time": "2025-06-08T10:00:00Z",
  "duration_minutes": 30
}
```

**Response:**
```json
{
  "message": "Usage session logged successfully",
  "points_earned": 25,
  "session": {
    "id": 1,
    "platform": "Instagram",
    "duration_minutes": 30,
    "points_earned": 25
  }
}
```

### GET /students/goals
Get student's current goals and progress.

**Response:**
```json
{
  "goals": [
    {
      "id": 1,
      "type": "daily_limit",
      "target_minutes": 120,
      "current_progress": 45,
      "status": "active"
    }
  ]
}
```

### POST /students/goals
Create a new goal for the student.

**Request Body:**
```json
{
  "type": "daily_limit",
  "target_minutes": 90,
  "start_date": "2025-06-08"
}
```

## Parent Endpoints

### GET /parents/children
Get list of linked children.

**Headers:**
```
Authorization: Bearer <token>
```

**Response:**
```json
{
  "children": [
    {
      "id": 1,
      "first_name": "John",
      "last_name": "Doe",
      "age": 19,
      "points_balance": 1250,
      "level": 3,
      "streak_days": 7
    }
  ]
}
```

### POST /parents/link-child
Link a child's account to parent account.

**Request Body:**
```json
{
  "child_email": "child@example.com"
}
```

**Response:**
```json
{
  "message": "Child linked successfully",
  "child": {
    "id": 1,
    "first_name": "John",
    "last_name": "Doe",
    "email": "child@example.com"
  }
}
```

### GET /parents/reports/{child_id}
Get detailed usage report for a specific child.

**Response:**
```json
{
  "total_usage_minutes": 315,
  "daily_stats": [
    {
      "date": "2025-06-08",
      "total_minutes": 45,
      "session_count": 3
    }
  ],
  "platform_stats": [
    {
      "platform": "Instagram",
      "total_minutes": 180,
      "avg_minutes": 30,
      "session_count": 6
    }
  ]
}
```

## Rewards Endpoints

### GET /rewards/
Get available rewards in the store.

**Query Parameters:**
- `category` (optional): Filter by reward category
- `min_points` (optional): Minimum points required
- `max_points` (optional): Maximum points required

**Response:**
```json
{
  "rewards": [
    {
      "id": 1,
      "title": "Starbucks $5 Gift Card",
      "description": "Enjoy your favorite coffee",
      "points_cost": 500,
      "category": "Food",
      "merchant_name": "Starbucks",
      "discount_percentage": null
    }
  ]
}
```

### GET /rewards/categories
Get list of available reward categories.

**Response:**
```json
{
  "categories": [
    "Food",
    "Shopping",
    "Entertainment",
    "Education"
  ]
}
```

### POST /rewards/redeem
Redeem a reward using points.

**Request Body:**
```json
{
  "reward_id": 1
}
```

**Response:**
```json
{
  "message": "Reward redeemed successfully",
  "reward": {
    "id": 1,
    "title": "Starbucks $5 Gift Card",
    "points_cost": 500
  },
  "redemption_code": "STBX-1234-5678",
  "remaining_points": 750
}
```

### GET /rewards/history
Get user's reward redemption history.

**Response:**
```json
{
  "redemptions": [
    {
      "id": 1,
      "reward_title": "Starbucks $5 Gift Card",
      "points_spent": 500,
      "redemption_code": "STBX-1234-5678",
      "redeemed_at": "2025-06-08T15:30:00Z",
      "status": "active"
    }
  ]
}
```

## Social Endpoints

### GET /social/leaderboard
Get friend leaderboard rankings.

**Response:**
```json
{
  "leaderboard": [
    {
      "student_id": 1,
      "name": "John Doe",
      "points": 1250,
      "level": 3,
      "is_current_user": true
    },
    {
      "student_id": 2,
      "name": "Jane Smith",
      "points": 980,
      "level": 2,
      "is_current_user": false
    }
  ]
}
```

### GET /social/friends
Get list of user's friends.

**Response:**
```json
{
  "friends": [
    {
      "id": 2,
      "name": "Jane Smith",
      "level": 2,
      "points": 980,
      "status": "online"
    }
  ]
}
```

### POST /social/add-friend
Send a friend request.

**Request Body:**
```json
{
  "friend_email": "friend@example.com"
}
```

**Response:**
```json
{
  "message": "Friend request sent successfully"
}
```

### GET /social/friend-requests
Get pending friend requests.

**Response:**
```json
{
  "friend_requests": [
    {
      "friendship_id": 1,
      "requester": {
        "id": 3,
        "name": "Mike Johnson",
        "level": 1
      },
      "created_at": "2025-06-08T12:00:00Z"
    }
  ]
}
```

### PUT /social/friend-requests/{friendship_id}/respond
Respond to a friend request.

**Request Body:**
```json
{
  "action": "accept" // or "reject"
}
```

**Response:**
```json
{
  "message": "Friend request accepted"
}
```

### GET /social/achievements
Get user's achievements and badges.

**Response:**
```json
{
  "achievements": [
    {
      "achievement": {
        "id": 1,
        "name": "First Steps",
        "description": "Complete your first day of reduced usage",
        "badge_icon": "🎯",
        "points_reward": 50
      },
      "earned": true,
      "earned_at": "2025-06-07T18:00:00Z"
    }
  ]
}
```

## Error Responses

All endpoints may return the following error responses:

### 400 Bad Request
```json
{
  "error": "Bad Request",
  "message": "Invalid input data"
}
```

### 401 Unauthorized
```json
{
  "error": "Unauthorized",
  "message": "Invalid or missing authentication token"
}
```

### 403 Forbidden
```json
{
  "error": "Forbidden",
  "message": "Insufficient permissions"
}
```

### 404 Not Found
```json
{
  "error": "Not Found",
  "message": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal Server Error",
  "message": "An unexpected error occurred"
}
```

## Rate Limiting

API endpoints are rate limited to prevent abuse:
- Authentication endpoints: 5 requests per minute
- General endpoints: 100 requests per minute
- Usage logging: 20 requests per minute

Rate limit headers are included in responses:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1625097600
```

## Webhooks

For real-time updates, the API supports webhooks for certain events:

### Available Events
- `user.registered` - New user registration
- `goal.achieved` - User achieves a goal
- `reward.redeemed` - User redeems a reward
- `achievement.earned` - User earns an achievement

### Webhook Payload Example
```json
{
  "event": "goal.achieved",
  "timestamp": "2025-06-08T15:30:00Z",
  "data": {
    "user_id": 1,
    "goal_id": 1,
    "points_earned": 50
  }
}
```


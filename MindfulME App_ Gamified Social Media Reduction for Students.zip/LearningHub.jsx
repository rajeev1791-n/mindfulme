import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { BookOpen, Play, CheckCircle, Clock, Star, Award } from 'lucide-react'

export default function LearningHub() {
  const [selectedCategory, setSelectedCategory] = useState('Digital Wellness')

  const categories = [
    'Digital Wellness',
    'Study Skills',
    'Career Guidance',
    'Mental Health',
    'Productivity'
  ]

  const courses = {
    'Digital Wellness': [
      {
        id: 1,
        title: 'Mindful Social Media Use',
        description: 'Learn how to use social media mindfully and maintain healthy digital habits.',
        duration: '45 min',
        progress: 75,
        completed: false,
        points: 100
      },
      {
        id: 2,
        title: 'Digital Detox Strategies',
        description: 'Effective techniques for taking breaks from technology and reconnecting with the real world.',
        duration: '30 min',
        progress: 100,
        completed: true,
        points: 80
      },
      {
        id: 3,
        title: 'Screen Time Management',
        description: 'Tools and techniques for managing your screen time across all devices.',
        duration: '35 min',
        progress: 0,
        completed: false,
        points: 90
      }
    ],
    'Study Skills': [
      {
        id: 4,
        title: 'Effective Note-Taking',
        description: 'Master different note-taking methods to improve your learning and retention.',
        duration: '40 min',
        progress: 60,
        completed: false,
        points: 120
      },
      {
        id: 5,
        title: 'Time Management for Students',
        description: 'Learn to balance academics, social life, and personal time effectively.',
        duration: '50 min',
        progress: 0,
        completed: false,
        points: 150
      }
    ],
    'Career Guidance': [
      {
        id: 6,
        title: 'Building Your Personal Brand',
        description: 'Create a professional online presence that showcases your skills and achievements.',
        duration: '60 min',
        progress: 25,
        completed: false,
        points: 200
      }
    ],
    'Mental Health': [
      {
        id: 7,
        title: 'Stress Management Techniques',
        description: 'Learn healthy ways to cope with stress and maintain mental well-being.',
        duration: '45 min',
        progress: 0,
        completed: false,
        points: 130
      }
    ],
    'Productivity': [
      {
        id: 8,
        title: 'Focus and Concentration',
        description: 'Improve your ability to focus and avoid distractions in our digital world.',
        duration: '40 min',
        progress: 0,
        completed: false,
        points: 110
      }
    ]
  }

  const featuredContent = [
    {
      title: 'Weekly Challenge: Digital Sunset',
      description: 'Try putting away all devices 1 hour before bedtime for better sleep.',
      type: 'Challenge',
      points: 50
    },
    {
      title: 'New Course: Social Media Psychology',
      description: 'Understand the psychology behind social media addiction and how to overcome it.',
      type: 'Course',
      points: 180
    }
  ]

  const startCourse = (courseId) => {
    alert(`Starting course ${courseId}. In a real app, this would navigate to the course content.`)
  }

  const continueCourse = (courseId) => {
    alert(`Continuing course ${courseId}. In a real app, this would resume from where you left off.`)
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Learning Hub</h1>
          <p className="text-gray-600 mt-1">Expand your knowledge and earn points</p>
        </div>
        <Card className="p-4">
          <div className="flex items-center space-x-2">
            <BookOpen className="h-5 w-5 text-blue-500" />
            <span className="text-sm text-gray-600">12 courses completed</span>
          </div>
        </Card>
      </div>

      {/* Featured Content */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Star className="h-5 w-5 text-yellow-500" />
            <span>Featured Content</span>
          </CardTitle>
          <CardDescription>Recommended courses and challenges for you</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {featuredContent.map((item, index) => (
              <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                <div className="flex justify-between items-start mb-2">
                  <Badge variant={item.type === 'Challenge' ? 'default' : 'secondary'}>
                    {item.type}
                  </Badge>
                  <div className="flex items-center space-x-1">
                    <Award className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm font-medium">{item.points}</span>
                  </div>
                </div>
                <h3 className="font-medium mb-1">{item.title}</h3>
                <p className="text-sm text-gray-600 mb-3">{item.description}</p>
                <Button size="sm" className="w-full">
                  {item.type === 'Challenge' ? 'Join Challenge' : 'Start Course'}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Category Navigation */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? 'default' : 'outline'}
            onClick={() => setSelectedCategory(category)}
            className="mb-2"
          >
            {category}
          </Button>
        ))}
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses[selectedCategory]?.map((course) => (
          <Card key={course.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <CardTitle className="text-lg">{course.title}</CardTitle>
                  <CardDescription className="mt-2">
                    {course.description}
                  </CardDescription>
                </div>
                {course.completed && (
                  <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0" />
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Award className="h-4 w-4 text-yellow-500" />
                    <span className="font-medium">{course.points} points</span>
                  </div>
                </div>

                {course.progress > 0 && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{course.progress}%</span>
                    </div>
                    <Progress value={course.progress} />
                  </div>
                )}

                <Button
                  onClick={() => course.progress > 0 ? continueCourse(course.id) : startCourse(course.id)}
                  className="w-full"
                  variant={course.completed ? 'outline' : 'default'}
                >
                  {course.completed ? (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Review Course
                    </>
                  ) : course.progress > 0 ? (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Continue
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Start Course
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Learning Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Courses Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">
              +2 this week
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Learning Streak</CardTitle>
            <Star className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">7 days</div>
            <p className="text-xs text-muted-foreground">
              Keep it up!
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Points Earned</CardTitle>
            <Award className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,240</div>
            <p className="text-xs text-muted-foreground">
              From learning activities
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


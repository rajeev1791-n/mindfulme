import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { useState, useEffect, createContext, useContext } from 'react'
import Login from './components/Login'
import Register from './components/Register'
import StudentDashboard from './components/StudentDashboard'
import ParentDashboard from './components/ParentDashboard'
import RewardsStore from './components/RewardsStore'
import LearningHub from './components/LearningHub'
import SocialFeatures from './components/SocialFeatures'
import Navigation from './components/Navigation'
import './App.css'

// Auth Context
const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

function App() {
  const [user, setUser] = useState(null)
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check for existing token on app load
    const token = localStorage.getItem('token')
    if (token) {
      fetchProfile(token)
    } else {
      setLoading(false)
    }
  }, [])

  const fetchProfile = async (token) => {
    try {
      const response = await fetch('http://localhost:5001/api/auth/profile', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
        setProfile(data.profile)
      } else {
        localStorage.removeItem('token')
      }
    } catch (error) {
      console.error('Failed to fetch profile:', error)
      localStorage.removeItem('token')
    } finally {
      setLoading(false)
    }
  }

  const login = (userData, profileData, token) => {
    setUser(userData)
    setProfile(profileData)
    localStorage.setItem('token', token)
  }

  const logout = () => {
    setUser(null)
    setProfile(null)
    localStorage.removeItem('token')
  }

  const authValue = {
    user,
    profile,
    login,
    logout,
    isAuthenticated: !!user
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-green-50">
        <div className="text-center">
          <img src="/src/assets/logo.png" alt="MindfulME" className="w-16 h-16 mx-auto mb-4" />
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <AuthContext.Provider value={authValue}>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
          {user && <Navigation />}
          
          <Routes>
            <Route 
              path="/login" 
              element={!user ? <Login /> : <Navigate to={user.user_type === 'student' ? '/student' : '/parent'} />} 
            />
            <Route 
              path="/register" 
              element={!user ? <Register /> : <Navigate to={user.user_type === 'student' ? '/student' : '/parent'} />} 
            />
            <Route 
              path="/student" 
              element={user?.user_type === 'student' ? <StudentDashboard /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/parent" 
              element={user?.user_type === 'parent' ? <ParentDashboard /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/rewards" 
              element={user?.user_type === 'student' ? <RewardsStore /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/learning" 
              element={user ? <LearningHub /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/social" 
              element={user?.user_type === 'student' ? <SocialFeatures /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/" 
              element={
                user ? 
                  <Navigate to={user.user_type === 'student' ? '/student' : '/parent'} /> : 
                  <Navigate to="/login" />
              } 
            />
          </Routes>
        </div>
      </Router>
    </AuthContext.Provider>
  )
}

export default App


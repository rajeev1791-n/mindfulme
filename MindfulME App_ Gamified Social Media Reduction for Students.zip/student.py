from flask import Blueprint, jsonify, request
from src.models.user import Student, UsageSession, PointsTransaction, db
from src.routes.auth import token_required
from datetime import datetime, timedelta
from sqlalchemy import func

student_bp = Blueprint('student', __name__)

@student_bp.route('/dashboard', methods=['GET'])
@token_required
def get_dashboard(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Access denied'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        # Get usage statistics for the last 7 days
        week_ago = datetime.utcnow() - timedelta(days=7)
        usage_stats = db.session.query(
            func.date(UsageSession.start_time).label('date'),
            func.sum(UsageSession.duration_minutes).label('total_minutes')
        ).filter(
            UsageSession.student_id == student.id,
            UsageSession.start_time >= week_ago
        ).group_by(func.date(UsageSession.start_time)).all()
        
        # Get recent points transactions
        recent_transactions = PointsTransaction.query.filter_by(
            student_id=student.id
        ).order_by(PointsTransaction.created_at.desc()).limit(10).all()
        
        # Calculate daily goal progress (example: limit to 2 hours per day)
        today = datetime.utcnow().date()
        today_usage = db.session.query(
            func.sum(UsageSession.duration_minutes)
        ).filter(
            UsageSession.student_id == student.id,
            func.date(UsageSession.start_time) == today
        ).scalar() or 0
        
        daily_goal_minutes = 120  # 2 hours
        goal_progress = max(0, (daily_goal_minutes - today_usage) / daily_goal_minutes * 100)
        
        return jsonify({
            'student': student.to_dict(),
            'usage_stats': [
                {
                    'date': stat.date.isoformat(),
                    'total_minutes': stat.total_minutes
                } for stat in usage_stats
            ],
            'recent_transactions': [t.to_dict() for t in recent_transactions],
            'today_usage_minutes': today_usage,
            'daily_goal_progress': min(100, goal_progress),
            'daily_goal_minutes': daily_goal_minutes
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get dashboard: {str(e)}'}), 500

@student_bp.route('/points', methods=['GET'])
@token_required
def get_points(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Access denied'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        # Get points history
        transactions = PointsTransaction.query.filter_by(
            student_id=student.id
        ).order_by(PointsTransaction.created_at.desc()).all()
        
        return jsonify({
            'points_balance': student.points_balance,
            'level': student.level,
            'streak_days': student.streak_days,
            'transactions': [t.to_dict() for t in transactions]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get points: {str(e)}'}), 500

@student_bp.route('/usage/session', methods=['POST'])
@token_required
def log_usage_session(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Access denied'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        data = request.json
        required_fields = ['platform', 'start_time', 'duration_minutes']
        for field in required_fields:
            if field not in data:
                return jsonify({'message': f'{field} is required'}), 400
        
        # Create usage session
        session = UsageSession(
            student_id=student.id,
            platform=data['platform'],
            start_time=datetime.fromisoformat(data['start_time'].replace('Z', '+00:00')),
            duration_minutes=data['duration_minutes']
        )
        
        # Calculate points earned (example: 1 point per minute under daily goal)
        daily_goal_minutes = 120  # 2 hours
        if data['duration_minutes'] < daily_goal_minutes:
            points_earned = daily_goal_minutes - data['duration_minutes']
            session.points_earned = points_earned
            
            # Update student points
            student.points_balance += points_earned
            
            # Create points transaction
            transaction = PointsTransaction(
                student_id=student.id,
                transaction_type='earned',
                points=points_earned,
                description=f'Reduced {data["platform"]} usage',
                reference_id=session.id
            )
            db.session.add(transaction)
        
        db.session.add(session)
        db.session.commit()
        
        return jsonify({
            'message': 'Usage session logged successfully',
            'session': session.to_dict(),
            'points_earned': session.points_earned
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to log session: {str(e)}'}), 500

@student_bp.route('/usage/stats', methods=['GET'])
@token_required
def get_usage_stats(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Access denied'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        # Get date range from query params
        days = request.args.get('days', 7, type=int)
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Get usage by platform
        platform_stats = db.session.query(
            UsageSession.platform,
            func.sum(UsageSession.duration_minutes).label('total_minutes'),
            func.count(UsageSession.id).label('session_count')
        ).filter(
            UsageSession.student_id == student.id,
            UsageSession.start_time >= start_date
        ).group_by(UsageSession.platform).all()
        
        # Get daily usage
        daily_stats = db.session.query(
            func.date(UsageSession.start_time).label('date'),
            func.sum(UsageSession.duration_minutes).label('total_minutes')
        ).filter(
            UsageSession.student_id == student.id,
            UsageSession.start_time >= start_date
        ).group_by(func.date(UsageSession.start_time)).all()
        
        return jsonify({
            'platform_stats': [
                {
                    'platform': stat.platform,
                    'total_minutes': stat.total_minutes,
                    'session_count': stat.session_count
                } for stat in platform_stats
            ],
            'daily_stats': [
                {
                    'date': stat.date.isoformat(),
                    'total_minutes': stat.total_minutes
                } for stat in daily_stats
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get usage stats: {str(e)}'}), 500

@student_bp.route('/goals', methods=['POST'])
@token_required
def set_goals(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Access denied'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        data = request.json
        # For now, we'll store goals in a simple way
        # In a real app, you might want a separate Goals table
        
        return jsonify({
            'message': 'Goals set successfully',
            'goals': data
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to set goals: {str(e)}'}), 500


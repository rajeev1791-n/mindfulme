# MindfulME App - Design System & Brand Guidelines

## Brand Identity

### Logo
The MindfulME logo features a stylized head silhouette with digital elements representing the mind's transformation through mindful technology use. The gradient from blue to green symbolizes the journey from digital overwhelm to balanced wellness.

### Color Palette
- **Primary Blue**: #4A90E2 (Trust, technology, focus)
- **Primary Green**: #7ED321 (Growth, wellness, achievement)
- **Secondary Blue**: #50C8E8 (Calm, clarity)
- **Secondary Green**: #9CCC65 (Progress, nature)
- **Neutral Gray**: #9B9B9B (Balance, sophistication)
- **Dark Gray**: #4A4A4A (Text, contrast)
- **Light Gray**: #F5F5F5 (Background, cards)

### Typography
- **Primary Font**: Inter (Clean, modern, readable)
- **Secondary Font**: Roboto (Technical, accessible)
- **Accent Font**: Poppins (Friendly, approachable)

## Design Principles

### 1. Mindful Simplicity
- Clean, uncluttered interfaces
- Purposeful use of white space
- Minimal cognitive load

### 2. Positive Reinforcement
- Encouraging color schemes
- Achievement-focused visuals
- Progress celebration elements

### 3. Accessibility First
- High contrast ratios
- Large touch targets (44px minimum)
- Clear visual hierarchy
- Screen reader compatibility

### 4. Mobile-First Design
- Responsive layouts
- Touch-friendly interactions
- Optimized for one-handed use

## UI Components

### Cards
- Rounded corners (8px radius)
- Subtle shadows (0 2px 8px rgba(0,0,0,0.1))
- Consistent padding (16px)
- Clear content hierarchy

### Buttons
- **Primary**: Blue gradient background, white text
- **Secondary**: Green outline, green text
- **Tertiary**: Gray text, no background
- Minimum height: 44px
- Border radius: 6px

### Progress Bars
- Green fill color (#7ED321)
- Light gray background (#E0E0E0)
- Rounded ends
- Smooth animations

### Icons
- Consistent stroke width (2px)
- Rounded line caps
- 24px standard size
- Scalable vector format

## Layout Guidelines

### Grid System
- 8px base unit
- 16px margins on mobile
- 24px margins on tablet
- Consistent spacing multiples (8, 16, 24, 32px)

### Navigation
- Bottom tab bar for primary navigation
- Top navigation for secondary actions
- Breadcrumbs for deep navigation
- Clear back button placement

### Content Hierarchy
- Large headings for primary content
- Medium headings for sections
- Body text for descriptions
- Small text for metadata

## Interaction Design

### Animations
- Smooth transitions (300ms ease-out)
- Meaningful motion
- Loading states with progress indicators
- Micro-interactions for feedback

### Gestures
- Swipe for navigation
- Pull-to-refresh for updates
- Long press for context menus
- Pinch-to-zoom for charts

### Feedback
- Haptic feedback for important actions
- Visual feedback for button presses
- Toast messages for confirmations
- Error states with clear messaging

## Responsive Breakpoints

### Mobile (320px - 768px)
- Single column layout
- Stacked navigation
- Full-width cards
- Large touch targets

### Tablet (768px - 1024px)
- Two-column layout
- Side navigation option
- Grid-based cards
- Optimized for landscape

### Desktop (1024px+)
- Multi-column layout
- Sidebar navigation
- Hover states
- Keyboard shortcuts

## Accessibility Standards

### WCAG 2.1 AA Compliance
- Color contrast ratio 4.5:1 minimum
- Keyboard navigation support
- Screen reader compatibility
- Focus indicators
- Alternative text for images

### Inclusive Design
- Support for various abilities
- Multiple input methods
- Flexible font sizing
- High contrast mode option


from flask import Blueprint, jsonify, request
from src.models.user import Reward, Student, PointsTransaction, db
from src.routes.auth import token_required

rewards_bp = Blueprint('rewards', __name__)

@rewards_bp.route('/', methods=['GET'])
@token_required
def get_rewards(current_user):
    try:
        # Get query parameters for filtering
        category = request.args.get('category')
        min_points = request.args.get('min_points', type=int)
        max_points = request.args.get('max_points', type=int)
        
        # Build query
        query = Reward.query.filter_by(active=True)
        
        if category:
            query = query.filter_by(category=category)
        if min_points:
            query = query.filter(Reward.points_cost >= min_points)
        if max_points:
            query = query.filter(Reward.points_cost <= max_points)
        
        rewards = query.order_by(Reward.points_cost.asc()).all()
        
        return jsonify({
            'rewards': [reward.to_dict() for reward in rewards]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get rewards: {str(e)}'}), 500

@rewards_bp.route('/categories', methods=['GET'])
@token_required
def get_categories(current_user):
    try:
        categories = db.session.query(Reward.category).filter_by(active=True).distinct().all()
        category_list = [cat[0] for cat in categories if cat[0]]
        
        return jsonify({
            'categories': category_list
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get categories: {str(e)}'}), 500

@rewards_bp.route('/redeem', methods=['POST'])
@token_required
def redeem_reward(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Only students can redeem rewards'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        data = request.json
        if 'reward_id' not in data:
            return jsonify({'message': 'reward_id is required'}), 400
        
        reward = Reward.query.filter_by(id=data['reward_id'], active=True).first()
        if not reward:
            return jsonify({'message': 'Reward not found or inactive'}), 404
        
        # Check if student has enough points
        if student.points_balance < reward.points_cost:
            return jsonify({
                'message': 'Insufficient points',
                'required_points': reward.points_cost,
                'current_points': student.points_balance
            }), 400
        
        # Deduct points
        student.points_balance -= reward.points_cost
        
        # Create transaction record
        transaction = PointsTransaction(
            student_id=student.id,
            transaction_type='redeemed',
            points=reward.points_cost,
            description=f'Redeemed: {reward.title}',
            reference_id=reward.id
        )
        
        db.session.add(transaction)
        db.session.commit()
        
        # In a real app, you would also:
        # 1. Generate a redemption code
        # 2. Send email/notification to student
        # 3. Notify merchant if applicable
        
        return jsonify({
            'message': 'Reward redeemed successfully',
            'reward': reward.to_dict(),
            'transaction': transaction.to_dict(),
            'remaining_points': student.points_balance
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to redeem reward: {str(e)}'}), 500

@rewards_bp.route('/history', methods=['GET'])
@token_required
def get_redemption_history(current_user):
    try:
        if current_user.user_type != 'student':
            return jsonify({'message': 'Only students can view redemption history'}), 403
        
        student = Student.query.filter_by(user_id=current_user.id).first()
        if not student:
            return jsonify({'message': 'Student profile not found'}), 404
        
        # Get redemption transactions
        transactions = PointsTransaction.query.filter_by(
            student_id=student.id,
            transaction_type='redeemed'
        ).order_by(PointsTransaction.created_at.desc()).all()
        
        # Get reward details for each transaction
        history = []
        for transaction in transactions:
            reward = Reward.query.get(transaction.reference_id) if transaction.reference_id else None
            history.append({
                'transaction': transaction.to_dict(),
                'reward': reward.to_dict() if reward else None
            })
        
        return jsonify({
            'redemption_history': history
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get redemption history: {str(e)}'}), 500

# Admin routes for managing rewards (would typically require admin authentication)
@rewards_bp.route('/admin/create', methods=['POST'])
@token_required
def create_reward(current_user):
    try:
        # In a real app, you'd check for admin privileges here
        data = request.json
        
        required_fields = ['title', 'points_cost']
        for field in required_fields:
            if field not in data:
                return jsonify({'message': f'{field} is required'}), 400
        
        reward = Reward(
            title=data['title'],
            description=data.get('description'),
            points_cost=data['points_cost'],
            category=data.get('category'),
            merchant_name=data.get('merchant_name'),
            discount_percentage=data.get('discount_percentage'),
            terms_conditions=data.get('terms_conditions')
        )
        
        db.session.add(reward)
        db.session.commit()
        
        return jsonify({
            'message': 'Reward created successfully',
            'reward': reward.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to create reward: {str(e)}'}), 500


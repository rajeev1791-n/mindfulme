import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useAuth } from '../App'
import { Award, ShoppingBag, Search, Filter, Star, Gift } from 'lucide-react'

export default function RewardsStore() {
  const { profile } = useAuth()
  const [rewards, setRewards] = useState([])
  const [categories, setCategories] = useState([])
  const [selectedCategory, setSelectedCategory] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchRewards()
    fetchCategories()
  }, [])

  const fetchRewards = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/rewards/', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setRewards(data.rewards)
      }
    } catch (error) {
      console.error('Failed to fetch rewards:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchCategories = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/rewards/categories', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setCategories(data.categories)
      }
    } catch (error) {
      console.error('Failed to fetch categories:', error)
    }
  }

  const redeemReward = async (rewardId) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/rewards/redeem', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ reward_id: rewardId })
      })

      const data = await response.json()

      if (response.ok) {
        alert(`Successfully redeemed: ${data.reward.title}`)
        // Refresh rewards and profile data
        fetchRewards()
        window.location.reload() // Simple way to refresh profile data
      } else {
        alert(data.message || 'Failed to redeem reward')
      }
    } catch (error) {
      console.error('Failed to redeem reward:', error)
      alert('Network error. Please try again.')
    }
  }

  const filteredRewards = rewards.filter(reward => {
    const matchesCategory = !selectedCategory || reward.category === selectedCategory
    const matchesSearch = !searchTerm || 
      reward.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      reward.description?.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-64 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Rewards Store</h1>
          <p className="text-gray-600 mt-1">Redeem your points for amazing rewards</p>
        </div>
        <Card className="p-4">
          <div className="flex items-center space-x-2">
            <Award className="h-5 w-5 text-yellow-500" />
            <span className="text-lg font-bold">{profile?.points_balance || 0}</span>
            <span className="text-sm text-gray-600">points</span>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search rewards..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="md:w-48">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Categories</SelectItem>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Rewards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRewards.map((reward) => (
          <Card key={reward.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <CardTitle className="text-lg">{reward.title}</CardTitle>
                  <CardDescription className="mt-1">
                    {reward.merchant_name && (
                      <Badge variant="outline" className="mr-2">
                        {reward.merchant_name}
                      </Badge>
                    )}
                    {reward.category && (
                      <Badge variant="secondary">
                        {reward.category}
                      </Badge>
                    )}
                  </CardDescription>
                </div>
                {reward.discount_percentage && (
                  <div className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-sm font-bold">
                    -{reward.discount_percentage}%
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-sm mb-4">
                {reward.description}
              </p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span className="font-bold text-lg">{reward.points_cost}</span>
                  <span className="text-sm text-gray-600">points</span>
                </div>
                
                <Button
                  onClick={() => redeemReward(reward.id)}
                  disabled={!profile || profile.points_balance < reward.points_cost}
                  className="bg-gradient-to-r from-blue-500 to-green-500 hover:from-blue-600 hover:to-green-600"
                >
                  <Gift className="h-4 w-4 mr-2" />
                  Redeem
                </Button>
              </div>
              
              {profile && profile.points_balance < reward.points_cost && (
                <p className="text-red-500 text-xs mt-2">
                  Need {reward.points_cost - profile.points_balance} more points
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredRewards.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <ShoppingBag className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No rewards found</h3>
            <p className="text-gray-600">
              {searchTerm || selectedCategory 
                ? 'Try adjusting your search or filter criteria'
                : 'Check back later for new rewards!'
              }
            </p>
          </CardContent>
        </Card>
      )}

      {/* Redemption History Link */}
      <Card>
        <CardContent className="p-4">
          <Button variant="outline" className="w-full">
            <Award className="h-4 w-4 mr-2" />
            View Redemption History
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}


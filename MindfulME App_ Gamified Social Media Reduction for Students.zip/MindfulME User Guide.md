# MindfulME User Guide

## Getting Started

Welcome to MindfulME! This guide will help you get the most out of your mindful social media journey.

## For Students

### Creating Your Account

1. **Download the App**: Get MindfulME from your app store
2. **Sign Up**: Choose "Student" and enter your details
3. **Age Verification**: Confirm you're between 13-25 years old
4. **Set Goals**: Choose your daily social media time limits
5. **Connect Accounts**: Link your social media for tracking (optional)

### Understanding Your Dashboard

#### Points Balance
- Your current points are displayed at the top
- Earn points by staying under your daily limits
- Bonus points for weekly streaks and challenges

#### Usage Tracking
- See your daily social media time
- Compare against your goals
- View weekly trends and patterns

#### Level System
- Start at Level 1 and progress by earning points
- Higher levels unlock better rewards
- Each level requires more points to advance

### Earning Points

#### Daily Goals
- **Under Limit**: 50 points for staying under daily goal
- **Significant Reduction**: 100 points for 50%+ reduction
- **Zero Usage**: 150 points for social media-free days

#### Weekly Challenges
- **7-Day Streak**: 200 bonus points
- **Weekly Reduction**: Points based on improvement
- **Family Challenges**: Extra points for group activities

#### Learning Activities
- **Complete Courses**: 50-200 points per course
- **Watch Videos**: 10-25 points per video
- **Take Quizzes**: 15-30 points per quiz

### Using the Reward Store

#### Browsing Rewards
- Filter by category (Food, Shopping, Entertainment, etc.)
- Sort by points required or popularity
- Check your points balance before selecting

#### Redeeming Rewards
1. Select a reward you can afford
2. Confirm redemption
3. Receive your unique code
4. Use the code at the merchant

#### Popular Rewards
- **Starbucks Gift Cards**: 500 points
- **Movie Tickets**: 1,200 points
- **Nike Discounts**: 800 points
- **Coursera Access**: 1,000 points

### Learning Hub

#### Course Categories
- **Digital Wellness**: Healthy tech habits
- **Study Skills**: Academic improvement
- **Career Guidance**: Professional development
- **Mental Health**: Stress management
- **Life Skills**: Practical knowledge

#### Progress Tracking
- See completion percentage
- Resume where you left off
- Earn certificates for completed courses

### Social Features

#### Adding Friends
1. Go to Social tab
2. Enter friend's email address
3. Send friend request
4. Wait for acceptance

#### Leaderboards
- Compare points with friends
- See weekly rankings
- Celebrate achievements together

#### Achievements
- Unlock badges for milestones
- Share accomplishments with friends
- Collect rare achievement icons

### Tips for Success

#### Setting Realistic Goals
- Start with small reductions (15-30 minutes less)
- Gradually decrease over time
- Focus on one platform at a time

#### Building Habits
- Check the app daily for motivation
- Use learning content during social media breaks
- Celebrate small wins and progress

#### Staying Motivated
- Connect with friends for accountability
- Participate in family challenges
- Focus on rewards you really want

## For Parents

### Setting Up Your Account

1. **Create Parent Account**: Choose "Parent" during registration
2. **Subscribe**: Select your monitoring plan
3. **Link Children**: Add your children's email addresses
4. **Set Permissions**: Configure monitoring preferences

### Monitoring Your Children

#### Dashboard Overview
- See all linked children at a glance
- View their points, levels, and streaks
- Quick access to detailed reports

#### Usage Reports
- Daily, weekly, and monthly summaries
- Platform-specific breakdowns
- Trend analysis and insights

#### Goal Management
- Help set appropriate limits
- Adjust goals based on progress
- Encourage gradual improvement

### Family Features

#### Family Challenges
- Create group goals for the whole family
- Track collective progress
- Celebrate achievements together

#### Communication
- Send encouraging messages
- Share achievements and milestones
- Discuss progress and challenges

### Parental Controls

#### Privacy Settings
- Control what data is shared
- Manage friend connections
- Set communication preferences

#### Account Management
- Modify goals and restrictions
- Approve reward redemptions
- Monitor spending and activity

### Supporting Your Child

#### Positive Reinforcement
- Celebrate progress, not just perfection
- Focus on effort and improvement
- Acknowledge challenges and setbacks

#### Open Communication
- Discuss digital wellness regularly
- Listen to their concerns and feedback
- Work together on solutions

#### Leading by Example
- Model healthy tech habits yourself
- Participate in family challenges
- Share your own digital wellness journey

## Troubleshooting

### Common Issues

#### App Not Tracking Usage
- Ensure permissions are granted
- Check that social media apps are linked
- Restart the app and try again

#### Points Not Updating
- Wait a few minutes for sync
- Check your internet connection
- Contact support if issues persist

#### Rewards Not Working
- Verify you have enough points
- Check the redemption code carefully
- Contact merchant if code doesn't work

#### Login Problems
- Check email and password spelling
- Try password reset if needed
- Clear app cache and try again

### Getting Help

#### In-App Support
- Use the Help section in settings
- Submit bug reports and feedback
- Access FAQ and tutorials

#### Contact Support
- Email: support@mindfulme.app
- Response time: 24-48 hours
- Include your account email and issue details

#### Community Resources
- Join our online community forum
- Connect with other users and families
- Share tips and success stories

## Privacy & Safety

### Data Protection
- We collect minimal necessary data
- All information is encrypted and secure
- You control what data is shared

### Account Security
- Use strong, unique passwords
- Enable two-factor authentication
- Log out on shared devices

### Digital Citizenship
- Be respectful in social features
- Report inappropriate behavior
- Practice good online habits

## Advanced Features

### Custom Goals
- Set personalized usage targets
- Create platform-specific limits
- Schedule goal adjustments

### Analytics
- Export your usage data
- View detailed progress reports
- Track long-term trends

### Integrations
- Connect with fitness trackers
- Sync with calendar apps
- Link to productivity tools

## Success Stories

### Student Testimonials
*"MindfulME helped me reduce my Instagram time by 60% and improve my grades!"* - Sarah, 17

*"The rewards system made it fun to spend less time on social media."* - Marcus, 19

*"I love competing with my friends to see who can be most mindful."* - Emma, 16

### Parent Feedback
*"Finally, a way to help my teenager without being the 'bad guy'."* - Jennifer, Parent

*"The family challenges brought us closer together."* - David, Parent

*"I can see real progress in my daughter's habits and mood."* - Lisa, Parent

## Updates & New Features

### Recent Updates
- Enhanced usage tracking accuracy
- New reward partners added
- Improved family challenge system
- Better progress visualization

### Coming Soon
- AI-powered insights and recommendations
- More learning content and courses
- Advanced parental controls
- Integration with school systems

---

*Need more help? Visit our website at www.mindfulme.app or contact our support team.*


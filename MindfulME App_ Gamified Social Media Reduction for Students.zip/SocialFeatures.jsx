import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { useAuth } from '../App'
import { Users, Trophy, UserPlus, MessageCircle, Target, Star, Award } from 'lucide-react'

export default function SocialFeatures() {
  const { profile } = useAuth()
  const [leaderboard, setLeaderboard] = useState([])
  const [friends, setFriends] = useState([])
  const [friendRequests, setFriendRequests] = useState([])
  const [achievements, setAchievements] = useState([])
  const [newFriendEmail, setNewFriendEmail] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchLeaderboard()
    fetchFriends()
    fetchFriendRequests()
    fetchAchievements()
  }, [])

  const fetchLeaderboard = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/social/leaderboard', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setLeaderboard(data.leaderboard)
      }
    } catch (error) {
      console.error('Failed to fetch leaderboard:', error)
    }
  }

  const fetchFriends = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/social/friends', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setFriends(data.friends)
      }
    } catch (error) {
      console.error('Failed to fetch friends:', error)
    }
  }

  const fetchFriendRequests = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/social/friend-requests', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setFriendRequests(data.friend_requests)
      }
    } catch (error) {
      console.error('Failed to fetch friend requests:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchAchievements = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/social/achievements', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setAchievements(data.achievements)
      }
    } catch (error) {
      console.error('Failed to fetch achievements:', error)
    }
  }

  const addFriend = async () => {
    if (!newFriendEmail) return

    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/social/add-friend', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ friend_email: newFriendEmail })
      })

      const data = await response.json()

      if (response.ok) {
        setNewFriendEmail('')
        alert('Friend request sent successfully!')
        fetchFriends()
      } else {
        alert(data.message || 'Failed to send friend request')
      }
    } catch (error) {
      console.error('Failed to add friend:', error)
      alert('Network error. Please try again.')
    }
  }

  const respondToFriendRequest = async (friendshipId, action) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`http://localhost:5000/api/social/friend-requests/${friendshipId}/respond`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ action })
      })

      if (response.ok) {
        fetchFriendRequests()
        fetchFriends()
        fetchLeaderboard()
      }
    } catch (error) {
      console.error('Failed to respond to friend request:', error)
    }
  }

  const getInitials = (name) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase()
  }

  const getRankIcon = (index) => {
    if (index === 0) return '🥇'
    if (index === 1) return '🥈'
    if (index === 2) return '🥉'
    return `#${index + 1}`
  }

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-64 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">Social Features</h1>
          <p className="text-gray-600 mt-1">Connect with friends and share your progress</p>
        </div>
        <Card className="p-4">
          <div className="flex items-center space-x-2">
            <Users className="h-5 w-5 text-blue-500" />
            <span className="text-sm text-gray-600">{friends.length} friends</span>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Leaderboard */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              <span>Friend Leaderboard</span>
            </CardTitle>
            <CardDescription>See how you rank among your friends</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {leaderboard.slice(0, 5).map((student, index) => (
                <div key={student.student_id} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="text-lg font-bold w-8">
                      {getRankIcon(index)}
                    </div>
                    <Avatar>
                      <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className={`font-medium ${student.is_current_user ? 'text-blue-600' : ''}`}>
                        {student.name} {student.is_current_user ? '(You)' : ''}
                      </p>
                      <p className="text-sm text-gray-500">Level {student.level}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold">{student.points}</p>
                    <p className="text-sm text-gray-500">points</p>
                  </div>
                </div>
              ))}
              {leaderboard.length === 0 && (
                <p className="text-center text-gray-500 py-4">
                  Add friends to see the leaderboard!
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Add Friends */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <UserPlus className="h-5 w-5 text-green-500" />
              <span>Add Friends</span>
            </CardTitle>
            <CardDescription>Connect with other MindfulME users</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex space-x-2">
                <Input
                  placeholder="friend@example.com"
                  value={newFriendEmail}
                  onChange={(e) => setNewFriendEmail(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={addFriend} className="bg-gradient-to-r from-blue-500 to-green-500">
                  Add
                </Button>
              </div>

              {/* Friend Requests */}
              {friendRequests.length > 0 && (
                <div className="space-y-3">
                  <h4 className="font-medium">Friend Requests</h4>
                  {friendRequests.map((request) => (
                    <div key={request.friendship_id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarFallback>{getInitials(request.requester.name)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{request.requester.name}</p>
                          <p className="text-sm text-gray-500">Level {request.requester.level}</p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          onClick={() => respondToFriendRequest(request.friendship_id, 'accept')}
                        >
                          Accept
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => respondToFriendRequest(request.friendship_id, 'reject')}
                        >
                          Decline
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Achievements */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Award className="h-5 w-5 text-purple-500" />
              <span>Achievements</span>
            </CardTitle>
            <CardDescription>Your earned badges and milestones</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {achievements.slice(0, 6).map((achievement) => (
                <div
                  key={achievement.achievement.id}
                  className={`p-3 rounded-lg border text-center ${
                    achievement.earned 
                      ? 'bg-blue-50 border-blue-200' 
                      : 'bg-gray-50 border-gray-200 opacity-60'
                  }`}
                >
                  <div className="text-2xl mb-1">
                    {achievement.achievement.badge_icon || '🏆'}
                  </div>
                  <p className="text-sm font-medium">{achievement.achievement.name}</p>
                  {achievement.earned && (
                    <Badge variant="secondary" className="mt-1 text-xs">
                      Earned
                    </Badge>
                  )}
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4">
              View All Achievements
            </Button>
          </CardContent>
        </Card>

        {/* Social Feed */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MessageCircle className="h-5 w-5 text-blue-500" />
              <span>Activity Feed</span>
            </CardTitle>
            <CardDescription>Recent achievements from your friends</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Mock social feed data */}
              <div className="flex items-center space-x-3">
                <Avatar>
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="text-sm">
                    <span className="font-medium">John Doe</span> earned the "Week Warrior" achievement
                  </p>
                  <p className="text-xs text-gray-500">2 hours ago</p>
                </div>
                <Star className="h-4 w-4 text-yellow-500" />
              </div>

              <div className="flex items-center space-x-3">
                <Avatar>
                  <AvatarFallback>AS</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="text-sm">
                    <span className="font-medium">Alice Smith</span> reached Level 5
                  </p>
                  <p className="text-xs text-gray-500">1 day ago</p>
                </div>
                <Trophy className="h-4 w-4 text-blue-500" />
              </div>

              <div className="flex items-center space-x-3">
                <Avatar>
                  <AvatarFallback>MB</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="text-sm">
                    <span className="font-medium">Mike Brown</span> completed a 7-day streak
                  </p>
                  <p className="text-xs text-gray-500">2 days ago</p>
                </div>
                <Target className="h-4 w-4 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Family Challenges */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5 text-green-500" />
            <span>Family Challenges</span>
          </CardTitle>
          <CardDescription>Work together with family members to achieve goals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium mb-2">Weekend Digital Detox</h4>
              <p className="text-sm text-gray-600 mb-3">
                Spend less than 2 hours on social media this weekend
              </p>
              <div className="flex items-center justify-between">
                <Badge variant="outline">In Progress</Badge>
                <span className="text-sm font-medium">2/4 family members</span>
              </div>
            </div>

            <div className="p-4 border rounded-lg">
              <h4 className="font-medium mb-2">Mindful Monday</h4>
              <p className="text-sm text-gray-600 mb-3">
                Start each Monday with 10 minutes of meditation
              </p>
              <div className="flex items-center justify-between">
                <Badge>Completed</Badge>
                <span className="text-sm font-medium">4/4 family members</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}


from flask import Blueprint, jsonify, request
from src.models.user import User, Student, Parent, db
import jwt
from functools import wraps

auth_bp = Blueprint('auth', __name__)

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, 'asdf#FGSgvasgf$5$WGT', algorithms=['HS256'])
            current_user = User.query.get(data['user_id'])
            if not current_user:
                return jsonify({'message': 'User not found'}), 401
        except jwt.ExpiredSignatureError:
            return jsonify({'message': 'Token has expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'message': 'Token is invalid'}), 401
        
        return f(current_user, *args, **kwargs)
    return decorated

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.json
        
        # Validate required fields
        required_fields = ['email', 'password', 'user_type', 'first_name', 'last_name']
        for field in required_fields:
            if field not in data:
                return jsonify({'message': f'{field} is required'}), 400
        
        # Check if user already exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'message': 'Email already registered'}), 400
        
        # Create user
        user = User(
            email=data['email'],
            user_type=data['user_type']
        )
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.flush()  # Get user ID
        
        # Create profile based on user type
        if data['user_type'] == 'student':
            if 'age' not in data:
                return jsonify({'message': 'Age is required for students'}), 400
            
            student = Student(
                user_id=user.id,
                first_name=data['first_name'],
                last_name=data['last_name'],
                age=data['age']
            )
            db.session.add(student)
            
        elif data['user_type'] == 'parent':
            parent = Parent(
                user_id=user.id,
                first_name=data['first_name'],
                last_name=data['last_name']
            )
            db.session.add(parent)
        
        db.session.commit()
        
        # Generate token
        token = user.generate_token('asdf#FGSgvasgf$5$WGT')
        
        return jsonify({
            'message': 'User registered successfully',
            'token': token,
            'user': user.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Registration failed: {str(e)}'}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.json
        
        if not data.get('email') or not data.get('password'):
            return jsonify({'message': 'Email and password are required'}), 400
        
        user = User.query.filter_by(email=data['email']).first()
        
        if not user or not user.check_password(data['password']):
            return jsonify({'message': 'Invalid email or password'}), 401
        
        token = user.generate_token('asdf#FGSgvasgf$5$WGT')
        
        # Get profile data
        profile = None
        if user.user_type == 'student':
            profile = Student.query.filter_by(user_id=user.id).first()
        elif user.user_type == 'parent':
            profile = Parent.query.filter_by(user_id=user.id).first()
        
        return jsonify({
            'message': 'Login successful',
            'token': token,
            'user': user.to_dict(),
            'profile': profile.to_dict() if profile else None
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Login failed: {str(e)}'}), 500

@auth_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    try:
        profile = None
        if current_user.user_type == 'student':
            profile = Student.query.filter_by(user_id=current_user.id).first()
        elif current_user.user_type == 'parent':
            profile = Parent.query.filter_by(user_id=current_user.id).first()
        
        return jsonify({
            'user': current_user.to_dict(),
            'profile': profile.to_dict() if profile else None
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get profile: {str(e)}'}), 500

@auth_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    try:
        data = request.json
        
        # Update user email if provided
        if 'email' in data:
            existing_user = User.query.filter_by(email=data['email']).first()
            if existing_user and existing_user.id != current_user.id:
                return jsonify({'message': 'Email already in use'}), 400
            current_user.email = data['email']
        
        # Update profile based on user type
        if current_user.user_type == 'student':
            profile = Student.query.filter_by(user_id=current_user.id).first()
            if profile:
                if 'first_name' in data:
                    profile.first_name = data['first_name']
                if 'last_name' in data:
                    profile.last_name = data['last_name']
                if 'age' in data:
                    profile.age = data['age']
                    
        elif current_user.user_type == 'parent':
            profile = Parent.query.filter_by(user_id=current_user.id).first()
            if profile:
                if 'first_name' in data:
                    profile.first_name = data['first_name']
                if 'last_name' in data:
                    profile.last_name = data['last_name']
        
        db.session.commit()
        
        return jsonify({
            'message': 'Profile updated successfully',
            'user': current_user.to_dict(),
            'profile': profile.to_dict() if profile else None
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Failed to update profile: {str(e)}'}), 500


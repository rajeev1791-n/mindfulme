import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '../App'
import { Users, TrendingUp, Settings, Plus, Clock, Target } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

export default function ParentDashboard() {
  const { user, profile } = useAuth()
  const [children, setChildren] = useState([])
  const [selectedChild, setSelectedChild] = useState(null)
  const [childReport, setChildReport] = useState(null)
  const [newChildEmail, setNewChildEmail] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchChildren()
  }, [])

  useEffect(() => {
    if (children.length > 0 && !selectedChild) {
      setSelectedChild(children[0])
    }
  }, [children])

  useEffect(() => {
    if (selectedChild) {
      fetchChildReport(selectedChild.id)
    }
  }, [selectedChild])

  const fetchChildren = async () => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/parents/children', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setChildren(data.children)
      }
    } catch (error) {
      console.error('Failed to fetch children:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchChildReport = async (childId) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`http://localhost:5000/api/parents/reports/${childId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setChildReport(data)
      }
    } catch (error) {
      console.error('Failed to fetch child report:', error)
    }
  }

  const linkChild = async () => {
    if (!newChildEmail) return

    try {
      const token = localStorage.getItem('token')
      const response = await fetch('http://localhost:5000/api/parents/link-child', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ child_email: newChildEmail })
      })

      if (response.ok) {
        setNewChildEmail('')
        fetchChildren()
      } else {
        const data = await response.json()
        alert(data.message || 'Failed to link child')
      }
    } catch (error) {
      console.error('Failed to link child:', error)
      alert('Network error. Please try again.')
    }
  }

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const chartData = childReport?.daily_stats?.map(stat => ({
    date: new Date(stat.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    minutes: stat.total_minutes,
    sessions: stat.session_count
  })) || []

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-800">
            Parent Dashboard
          </h1>
          <p className="text-gray-600 mt-1">Monitor and support your children's digital wellness</p>
        </div>
        <Badge variant="outline" className="text-sm">
          Subscription: {profile?.subscription_status || 'trial'}
        </Badge>
      </div>

      {/* Link Child Section */}
      {children.length === 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Plus className="h-5 w-5" />
              <span>Link Your First Child</span>
            </CardTitle>
            <CardDescription>
              Enter your child's email address to start monitoring their progress
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-4">
              <Input
                placeholder="child@example.com"
                value={newChildEmail}
                onChange={(e) => setNewChildEmail(e.target.value)}
                className="flex-1"
              />
              <Button onClick={linkChild} className="bg-gradient-to-r from-blue-500 to-green-500">
                Link Child
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Children Overview */}
      {children.length > 0 && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {children.map((child) => (
              <Card 
                key={child.id} 
                className={`cursor-pointer transition-all ${
                  selectedChild?.id === child.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => setSelectedChild(child)}
              >
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{child.first_name} {child.last_name}</span>
                    <Users className="h-5 w-5 text-blue-500" />
                  </CardTitle>
                  <CardDescription>Age: {child.age}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Points:</span>
                      <Badge variant="secondary">{child.points_balance}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Level:</span>
                      <Badge variant="outline">Level {child.level}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Streak:</span>
                      <span className="text-sm font-medium">{child.streak_days} days</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Add Child Card */}
            <Card className="border-dashed border-2 border-gray-300 hover:border-gray-400 transition-colors">
              <CardContent className="flex flex-col items-center justify-center h-full p-6">
                <Plus className="h-8 w-8 text-gray-400 mb-2" />
                <p className="text-sm text-gray-600 mb-4">Add another child</p>
                <div className="w-full space-y-2">
                  <Input
                    placeholder="child@example.com"
                    value={newChildEmail}
                    onChange={(e) => setNewChildEmail(e.target.value)}
                    size="sm"
                  />
                  <Button onClick={linkChild} size="sm" className="w-full">
                    Link Child
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Selected Child Report */}
          {selectedChild && childReport && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5" />
                    <span>{selectedChild.first_name}'s Usage Report</span>
                  </CardTitle>
                  <CardDescription>
                    Last 7 days • Total usage: {childReport.total_usage_minutes} minutes
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="minutes" fill="#3b82f6" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Breakdown</CardTitle>
                    <CardDescription>Usage by social media platform</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {childReport.platform_stats?.map((platform, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{platform.platform}</p>
                            <p className="text-sm text-gray-500">
                              Avg: {Math.round(platform.avg_minutes)}m per session
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold">{platform.total_minutes}m</p>
                            <p className="text-sm text-gray-500">total</p>
                          </div>
                        </div>
                      )) || (
                        <p className="text-sm text-gray-500">No usage data available</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Settings className="h-5 w-5" />
                      <span>Controls & Settings</span>
                    </CardTitle>
                    <CardDescription>Manage {selectedChild.first_name}'s account</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <Button variant="outline" className="w-full justify-start">
                        <Target className="h-4 w-4 mr-2" />
                        Set Daily Goals
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Clock className="h-4 w-4 mr-2" />
                        Time Restrictions
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Users className="h-4 w-4 mr-2" />
                        Friend Management
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}

